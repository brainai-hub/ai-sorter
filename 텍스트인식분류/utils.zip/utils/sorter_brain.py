import cv2
import numpy as np
from openvino.runtime import Core

class Text_Model:

    def __init__(self):
        print("-- Models --")
        self.detection_model, self.horizontal_output = self.load_text_model('horizontal-text-detection-0001')
        self.recognition_model, self.recognition_output = self.load_text_model('text-recognition-0014')

        self.characters = "#1234567890abcdefghijklmnopqrstuvwxyz"
        self.conf_d = .4
        self.conf_r = .8

    def load_text_model(self, model_name):
        print("Loading:", model_name)
        model =  "models/" + model_name + ".xml"
        ie = Core()
        model = ie.read_model(model=model)
        compiled_model = ie.compile_model(model=model, device_name="CPU")
        input_layer = model.input(0)
        output_layer = compiled_model.output(0)
        try:
            print("Input layer shape:", input_layer.shape)
            print("Output layer shape:", output_layer.shape, "\n")
        except:
            print("Cannot print out layer shapes", "\n")
        return compiled_model,  output_layer

    def infer_model_detection(self, frame):
        resized_frame = cv2.resize(src=frame, dsize=(704, 704))
        transposed_frame = resized_frame.transpose(2, 0, 1)
        input_frame = np.expand_dims(transposed_frame, 0)
        self.predictions_d = self.detection_model([input_frame])[self.horizontal_output]
        text_boxes = []
        for i in range(len(self.predictions_d)):
            if self.predictions_d[i][4]> self.conf_d:
                (xmin, ymin, xmax, ymax, _)  = self.predictions_d[i].astype("int")
                conf = self.predictions_d[i][4]
                h, w, c = np.shape(frame)
                xmin = int(xmin/704*w)
                xmax = int(xmax/704*w)
                ymin = int(ymin/704*h)
                ymax = int(ymax/704*h)
                box = (xmin, xmax, ymin, ymax, conf)
                text_boxes.append(box)
        return text_boxes

    def infer_model_recognition(self, frame, output_d):
        words = []
        for i in range(len(output_d)):
            model_input = []
            xmin, xmax, ymin, ymax, conf = output_d[i]
            crop_frame = frame[ymin:ymax, xmin:xmax]
            crop_gray = cv2.cvtColor(crop_frame, cv2.COLOR_BGR2GRAY)
            (n, c, h, w) = (1,1,32,128)
            input_image = np.ndarray(shape=(n, c, h, w))
            if crop_gray.shape[:-1] != (h, w):
                crop_gray = cv2.resize(crop_gray, (w, h))
            input_image[0] = crop_gray
            output_r = self.recognition_model([input_image])[self.recognition_output]
            word = ''
            for i in output_r:
                letter_index = np.argmax(i)
                letter = self.characters[letter_index]
                if letter != '#':
                    word += letter
            words.append(word)
        return words

    def predictions(self, frame):
        output_d = self.infer_model_detection(frame)
        output_r = self.infer_model_recognition(frame, output_d)
        return output_d, output_r

    def draw(self, output_d, output_r, frame):
        for i in range(len(output_d)):
            xmin, xmax, ymin, ymax, conf = output_d[i]
            cv2.rectangle(frame, (xmin, ymin), (xmax, ymax), (0, 255, 0), 1)
            if output_r:
                text = output_r[i]
                cv2.putText(frame, text, (xmin, ymin), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
